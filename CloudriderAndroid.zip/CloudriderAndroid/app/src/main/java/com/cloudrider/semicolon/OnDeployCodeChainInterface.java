package com.cloudrider.semicolon;

public interface OnDeployCodeChainInterface {
    public void onSubscribe(String peer);
}
